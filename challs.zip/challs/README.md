Start by running the command:
unzip level0.zip
